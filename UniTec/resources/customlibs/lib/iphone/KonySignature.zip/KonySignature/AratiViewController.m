//
//  AratiViewController.m
//  AratiSignature
//
//  Created by Mayank Tiwari on 30/05/18.
//  Copyright © 2018 Mayank Tiwari. All rights reserved.
//

#import "AratiViewController.h"

@interface AratiViewController ()

@end

@implementation AratiViewController

-(void)loadView {
    self.view = [[UIView alloc] initWithFrame:CGRectMake(20.0, 100.0, 380, 800) ];
    self.view.backgroundColor = [UIColor blackColor];
    self.painterView = [[SignaturePainterView alloc] init];
    [self.view addSubview:self.painterView];
    self.painterView.translatesAutoresizingMaskIntoConstraints = NO;
    NSLog(@"Log", _installState);
    if(_installState == NULL){
        [[self.painterView.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor] setActive:YES];
    }else{
        [[self.painterView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor] setActive:YES];
    }
    [[self.painterView.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor] setActive:YES];
     
    
    [[self.painterView.heightAnchor constraintEqualToAnchor:self.painterView.widthAnchor multiplier:215.f/362.f] setActive:YES];
    [[self.painterView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:8] setActive:YES];
    [[self.painterView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-8] setActive:YES];
    
    if(_installState == NULL){
        
    }
    else{
        UILabel *installStateTitle;
        installStateTitle = [ [UILabel alloc ] initWithFrame:CGRectMake(20.0, 60.0, 300.0, 40.0) ];
        installStateTitle.textAlignment =  UITextAlignmentLeft;
        installStateTitle.textColor = [UIColor whiteColor];
        installStateTitle.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:(20.0)];
        [self.view addSubview:installStateTitle];
        installStateTitle.text = @"Etat de l'installation : ";
        
        UITextView *installState;
        installState = [ [UITextView alloc ] initWithFrame:CGRectMake(20.0, 90.0, 385.0, 170.0) ];
        installState.textAlignment =  UITextAlignmentLeft;
        [installState setScrollEnabled:YES];
        installState.editable = false;
        [installState setUserInteractionEnabled:YES];
        [installState setBackgroundColor:[UIColor clearColor]];
        installState.textColor = [UIColor whiteColor];
        installState.font = [UIFont fontWithName:@"Arial Rounded MT" size:(15.0)];
        //installState.numberOfLines = 0;
        installState.text = _installState;
           [self.view addSubview:installState];
        
        UILabel *compensatoryMeasureTitle;
        compensatoryMeasureTitle = [ [UILabel alloc ] initWithFrame:CGRectMake(20.0, 250.0, 300.0, 40.0) ];
        compensatoryMeasureTitle.textAlignment =  UITextAlignmentLeft;
        compensatoryMeasureTitle.textColor = [UIColor whiteColor];
        compensatoryMeasureTitle.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:(20.0)];
        [self.view addSubview:compensatoryMeasureTitle];
        compensatoryMeasureTitle.text = @"Mesures Compensatoire : ";
        
        UITextView *compensatoryMeasure;
        compensatoryMeasure = [ [UITextView alloc ] initWithFrame:CGRectMake(20.0, 280.0, 385.0, 180.0) ];
        compensatoryMeasure.textAlignment =  UITextAlignmentLeft;
        [compensatoryMeasure setScrollEnabled:YES];
        compensatoryMeasure.editable = false;
        [compensatoryMeasure setUserInteractionEnabled:YES];
        [compensatoryMeasure setBackgroundColor:[UIColor clearColor]];
        compensatoryMeasure.textColor = [UIColor whiteColor];
        compensatoryMeasure.font = [UIFont fontWithName:@"Arial Rounded MT" size:(15.0)];
        //installState.numberOfLines = 0;
        compensatoryMeasure.text = _compensatoryMeasure;
        [self.view addSubview:compensatoryMeasure];
        
        UILabel *SignatureTitle;
        SignatureTitle = [ [UILabel alloc ] initWithFrame:CGRectMake(0.0, 460.0, 400, 40.0) ];
        SignatureTitle.textAlignment =  UITextAlignmentCenter;
        SignatureTitle.textColor = [UIColor whiteColor];
        SignatureTitle.font = [UIFont fontWithName:@"Arial Rounded MT Bold" size:(20.0)];
        [self.view addSubview:SignatureTitle];
        SignatureTitle.text = @"Signature : ";
    }
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [super viewDidLoad];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelTouched:)];
	self.navigationItem.leftBarButtonItem = leftItem;
    //[leftItem release];
    
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(doneTouched:)];
    self.navigationItem.rightBarButtonItem = rightItem;
    //[rightItem release];
    
    self.painterView.strokeWidth         = self.strokeWidth;
    self.painterView.strokeColor         = self.strokeColor;
    self.painterView.showClearButton     = self.showClearButton;
    self.painterView.shakeToClearEnabled = self.shakeToClearEnabled;
    self.painterView.installState = self.installState;
    self.painterView.compensatoryMeasure = self.compensatoryMeasure;
    
   /* UITextField *textField = [[UITextField alloc]initWithFrame:CGRectMake(10, 10, 29, 40)];
    [textField setBorderStyle:UITextBorderStyleRoundedRect];
    [self.view addSubview:textField];
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(10, 10, 29, 40)];
    label.text = @"Custom Label";
    [label setFont:[UIFont boldSystemFontOfSize:16]];
    [self.view addSubview:label];*/
    

    
}

- (void)dealloc {
    self.strokeColor = nil;
   // [super dealloc];
}

- (void)cancelTouched:(id)sender {
    if ([self.delegate respondsToSelector:@selector(signaturePainterDidCancel:)]) {
        [self.delegate signaturePainterDidCancel:self];
    }
}

- (void)doneTouched:(id)sender {
    if ([self.delegate respondsToSelector:@selector(signaturePainterDidFinishDrawing:)]) {
        [self.delegate signaturePainterDidFinishDrawing:self];
    }
}

@end
