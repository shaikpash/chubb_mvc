//
//  AratiViewController.h
//  AratiSignature
//
//  Created by Mayank Tiwari on 30/05/18.
//  Copyright © 2018 Mayank Tiwari. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SignaturePainterView.h"

@class AratiViewController;

@protocol AratiViewControllerDelegate <NSObject>
@optional
- (void)signaturePainterDidCancel:(AratiViewController *)painter;
- (void)signaturePainterDidFinishDrawing:(AratiViewController *)painter;
@end


@interface AratiViewController : UIViewController
@property (nonatomic, strong) IBOutlet SignaturePainterView* painterView;
@property (nonatomic, assign) id<AratiViewControllerDelegate> delegate;
//@property (nonatomic, assign, readonly) SignaturePainterView *painterView;

@property(nonatomic,assign) CGFloat                     strokeWidth;
@property(nonatomic,retain) NSString                    *strokeColor;
@property(nonatomic,assign) BOOL                        showClearButton;   //If YES clear button to clear, else if NO long tap to clear
@property(nonatomic,assign) BOOL                        shakeToClearEnabled;
@property(nonatomic,retain) NSString                    *installState;
@property(nonatomic,retain) NSString                    *compensatoryMeasure;

@end

