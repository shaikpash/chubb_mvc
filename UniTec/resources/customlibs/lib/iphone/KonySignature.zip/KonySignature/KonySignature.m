//
//  KonySignature.m
//  KonySignature
//
//  Created by adan on 25.07.13.
//  Copyright (c) 2013 Softserve. All rights reserved.
//

#import "CallBack.h"
#import "lglobals.h"

#import <UIKit/UIKit.h>
#import "KonySignature.h"
#import "AratiViewController.h"


#pragma mark - Root Controller -

@interface KonySignatureRootViewController : UIViewController <AratiViewControllerDelegate>
@property (retain) UIWindow *currentWindow;
@property (retain) UIViewController *currentController;
@property (assign) BOOL alreadyPresentViewController;

@property (retain) CallBack *callback;

- (void)dismiss;
@end


@implementation KonySignatureRootViewController

- (void)dismiss {
    [[self->_currentController retain] autorelease];
    self.currentController = nil;
    [self performSelector:@selector(removeCurrentWindow) withObject:nil afterDelay:0.1];
    
}

- (void)removeCurrentWindow {
    [[_currentWindow retain] autorelease];
    _currentWindow.hidden = YES;
    _currentWindow.rootViewController = nil;
    self.currentWindow = nil;
}

- (void)dealloc {
    self.currentWindow = nil;
    self.currentController = nil;
    self.callback = nil;
    [super dealloc];
}

- (void)loadView {
    self.view = [[[UIView alloc] init] autorelease];
    self.view.opaque = NO;
    self.view.backgroundColor = [UIColor whiteColor];

}


- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
    if (self.alreadyPresentViewController) {
        return;
    }
    
    self.alreadyPresentViewController = YES;
    
    if (self.currentController != nil) {
        [self presentViewController:self.currentController
                           animated:NO
                         completion:nil];
    }

}



#pragma mark - AratiViewControllerDelegate -

- (void)signaturePainterDidCancel:(AratiViewController *) __unused painter {
    [self dismiss];
}

- (void)signaturePainterDidFinishDrawing:(AratiViewController *) painter {
    if (self.callback != nil) {
        NSArray *args = [[NSArray alloc] initWithObjects:[painter.painterView getSignatureImageBase64], nil];
        doExecuteClosure(self.callback, args);
        [args release];
    }
    [self dismiss];
}

@end


#pragma mark - Entry Point -

@implementation KonySignature
+ (NSInteger)presentSignanurePainterWithTitle:(NSString *)title
                                  strokeWidth:(CGFloat)strokeWidth
                                  strokeColor:(NSString *)hexColor
                               showClearButon:(BOOL)showClearButon
                         shakeToCancelEnabled:(BOOL)shakeToCancelEnabled
                                 installState:(NSString *)installState
                          compensatoryMeasure:(NSString *)compensatoryMeasure
                                     callback:(CallBack *)callback {
    
    KonySignatureRootViewController *root = [[[KonySignatureRootViewController alloc] init] autorelease];
    root.callback = callback;
    
    UIWindow *wnd = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    root.currentWindow = wnd;
    wnd.rootViewController = root;
    wnd.opaque = NO;
    wnd.backgroundColor = [UIColor clearColor];
    
    AratiViewController *painterController = [AratiViewController new];
    painterController.delegate = root;
    //setup painter
    painterController.title = title;
    painterController.strokeWidth         = strokeWidth;
    painterController.strokeColor         = hexColor;
    painterController.showClearButton     = showClearButon;
    painterController.installState = installState;
    painterController.compensatoryMeasure = compensatoryMeasure;
    //NSLog(painterController.installState);
    
    painterController.shakeToClearEnabled = shakeToCancelEnabled;
    
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:painterController];
    
    root.currentController = navigationController;
    
    [painterController release];
    [navigationController release];
    
    [wnd makeKeyAndVisible];
    
    return KonySignatureResultOk;
}
@end
