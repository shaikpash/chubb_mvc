//
//
//  ScanBarCodes
//
//  Created by Srinivas Vemula 7/20/2015
// Updated by @MatDeuh 02/01/2018
//
// This code is used to scan barcodes using native iOS AVCapture classes. We do not need any third party libraries to do this job. This works only on iOS 7+ OS versions and it supports the below types of barcodes UPC-A
//  --> UPC-E
//  --> Code 39
//  --> Code 39 mod 43
//  --> Code 93
//  --> Code 128
//  --> EAN-8
//  --> EAN-13
//  --> Aztec
//  --> PDF417
//  --> QR

#import <AVFoundation/AVFoundation.h>
#import "MyBarcodeCapture.h"

@interface MyBarcodeCapture () <AVCaptureMetadataOutputObjectsDelegate>
{
    AVCaptureSession *_session;
    AVCaptureDevice *_device;
    AVCaptureDeviceInput *_input;
    AVCaptureMetadataOutput *_output;
    AVCaptureVideoPreviewLayer *_prevLayer;
    UIButton *closeButton;
    UIView *_highlightView;
    UILabel *indicationLabel;
    UIButton *zoomInButton;
    UIButton *zoomOutButton;
    UIButton *flashButton;
    
}
@end

@implementation MyBarcodeCapture

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    //adding the layer after creating it
    
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    
    
    
    
    
    // Initially make the captureSession object nil.
    
    _highlightView = [[UIView alloc] init];
    _highlightView.autoresizingMask = UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleBottomMargin;
    _highlightView.layer.borderColor = [UIColor greenColor].CGColor;
    _highlightView.layer.borderWidth = 3;
    [self.view addSubview:_highlightView];
    
    
    closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [closeButton setFrame:CGRectMake(0, self.view.bounds.size.height - 50, self.view.bounds.size.width, 50)];
    closeButton.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    [closeButton setTitle:@"Retour" forState:UIControlStateNormal];
    [closeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [closeButton.titleLabel setFont:[UIFont systemFontOfSize:20]];
    [closeButton addTarget:self action:@selector(closeButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [closeButton setBackgroundColor: [UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:1.0]];
    [self.view addSubview:closeButton];
    
    zoomInButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [zoomInButton setFrame:CGRectMake(self.view.bounds.size.width-70, self.view.bounds.size.height - 200, 60, 60)];
    zoomInButton.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    [zoomInButton setTitle:@"+" forState:UIControlStateNormal];
    [zoomInButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [zoomInButton.titleLabel setFont:[UIFont systemFontOfSize:25]];
    [zoomInButton addTarget:self action:@selector(zoomInFunction:) forControlEvents:UIControlEventTouchUpInside];
    [zoomInButton setBackgroundColor: [UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:1.0]];
    zoomInButton.clipsToBounds = YES;
    
    //half of the width
    zoomInButton.layer.cornerRadius = 60/2.0f;
    
    [self.view addSubview:zoomInButton];
    
    zoomOutButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [zoomOutButton setFrame:CGRectMake(self.view.bounds.size.width-70, self.view.bounds.size.height - 130, 60, 60)];
    zoomOutButton.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    [zoomOutButton setTitle:@"-" forState:UIControlStateNormal];
    [zoomOutButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [zoomOutButton.titleLabel setFont:[UIFont systemFontOfSize:25]];
    [zoomOutButton addTarget:self action:@selector(zoomOutFunction:) forControlEvents:UIControlEventTouchUpInside];
    [zoomOutButton setBackgroundColor: [UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:1.0]];
    zoomOutButton.clipsToBounds = YES;
    
    zoomOutButton.layer.cornerRadius = 60/2.0f;
    
    [self.view addSubview:zoomOutButton];
    
    flashButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [flashButton setFrame:CGRectMake(self.view.bounds.size.width-70, self.view.bounds.size.height - 290, 60, 60)];
    flashButton.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
    [flashButton setImage:[UIImage imageNamed:@"torch.png"] forState:UIControlStateNormal];
    [flashButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [flashButton.titleLabel setFont:[UIFont systemFontOfSize:25]];
    [flashButton addTarget:self action:@selector(flashFunction:) forControlEvents:UIControlEventTouchUpInside];
    [flashButton setBackgroundColor: [UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:1.0]];
    flashButton.clipsToBounds = YES;
    
    flashButton.layer.cornerRadius = 60/2.0f;
    
    [self.view addSubview:flashButton];
    
    //half of the width
    
    
    
    
    _session = [[AVCaptureSession alloc] init];
    _device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    NSError *error = nil;
    
    _input = [AVCaptureDeviceInput deviceInputWithDevice:_device error:&error];
    if (_input) {
        [_session addInput:_input];
    } else {
        NSLog(@"Error: %@", error);
    }
    
    _output = [[AVCaptureMetadataOutput alloc] init];
    [_output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    [_session addOutput:_output];
    
    _output.metadataObjectTypes = [_output availableMetadataObjectTypes];
    
    _prevLayer = [AVCaptureVideoPreviewLayer layerWithSession:_session];
    _prevLayer.frame = self.view.frame;
    _prevLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    _prevLayer.bounds=self.view.bounds;
    _prevLayer.position=CGPointMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds));
    
    [self.view.layer addSublayer:_prevLayer];
    
    
    
    CAShapeLayer *rectLayer = [CAShapeLayer layer];
    [rectLayer setPath:[[UIBezierPath bezierPathWithRect:CGRectMake(self.view.bounds.size.width/8, (self.view.bounds.size.height/9) * 3, (self.view.bounds.size.width/8) * 6, (self.view.bounds.size.height/9) * 3)] CGPath]];
    [rectLayer setStrokeColor:[[UIColor redColor] CGColor]];
    [rectLayer setFillColor:[[UIColor clearColor] CGColor]];
    
    CAShapeLayer *rectLayerMaskTop = [CAShapeLayer layer];
    [rectLayerMaskTop setPath:[[UIBezierPath bezierPathWithRect:CGRectMake(0, 0, self.view.bounds.size.width, ((self.view.bounds.size.height/9) * 3))] CGPath]];
    [rectLayerMaskTop setFillColor:[[UIColor colorWithWhite:0 alpha:0.5] CGColor]];
    
    CAShapeLayer *rectLayerMaskLeft = [CAShapeLayer layer];
    [rectLayerMaskLeft setPath:[[UIBezierPath bezierPathWithRect:CGRectMake(0, (self.view.bounds.size.height/9) * 3, self.view.bounds.size.width/8, (self.view.bounds.size.height/9) * 3)] CGPath]];
    [rectLayerMaskLeft setFillColor:[[UIColor colorWithWhite:0 alpha:0.5] CGColor]];
    
    CAShapeLayer *rectLayerMaskRight = [CAShapeLayer layer];
    [rectLayerMaskRight setPath:[[UIBezierPath bezierPathWithRect:CGRectMake((self.view.bounds.size.width/8) * 7, (self.view.bounds.size.height/9) * 3, self.view.bounds.size.width/8, (self.view.bounds.size.height/9) * 3)] CGPath]];
    [rectLayerMaskRight setFillColor:[[UIColor colorWithWhite:0 alpha:0.5] CGColor]];
    
    CAShapeLayer *rectLayerMaskBottom = [CAShapeLayer layer];
    [rectLayerMaskBottom setPath:[[UIBezierPath bezierPathWithRect:CGRectMake(0, (self.view.bounds.size.height/9) * 6, self.view.bounds.size.width, (self.view.bounds.size.height/9) * 4)] CGPath]];
    [rectLayerMaskBottom setFillColor:[[UIColor colorWithWhite:0 alpha:0.5] CGColor]];
    
    [self.view.layer addSublayer:rectLayer];
    [self.view.layer addSublayer:rectLayerMaskTop];
    [self.view.layer addSublayer:rectLayerMaskLeft];
    [self.view.layer addSublayer:rectLayerMaskRight];
    [self.view.layer addSublayer:rectLayerMaskBottom];
    
    indicationLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 100, self.view.bounds.size.width, 20)];
    
    [indicationLabel setTextColor:[UIColor whiteColor]];
    [indicationLabel setTextAlignment:UITextAlignmentCenter];
    [indicationLabel setBackgroundColor:[UIColor clearColor]];
    [indicationLabel setFont:[UIFont fontWithName:@"Trebuchet MS" size: 20.0f]];
    [indicationLabel setText:@"Veuillez scanner un code-barre"];
    [self.view addSubview:indicationLabel];
    
    
    
    [_session startRunning];
    
    [self.view bringSubviewToFront:_highlightView];
    [self.view bringSubviewToFront:closeButton];
    [self.view bringSubviewToFront:zoomInButton];
    [self.view bringSubviewToFront:zoomOutButton];
    [self.view bringSubviewToFront:flashButton];
    
    
}

-(IBAction)closeButtonAction:(id)sender{
    [_session release];
    [self dismissViewControllerAnimated:YES completion:nil];
    if ([_device hasTorch] && [_device hasFlash]){
        
        [_device lockForConfiguration:nil];
    if (_device.torchMode == AVCaptureTorchModeOn)
    {
        [_device setTorchMode:AVCaptureTorchModeOff];
    }
    }
    [_session stopRunning];

}

// This method will be called once all the subviews are loaded. Using this method we are changing the orientation of camera preview layer.

- (void)viewDidLayoutSubviews
{
    CGRect bounds=self.view.layer.bounds;
    _prevLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    _prevLayer.bounds=bounds;
    _prevLayer.position=CGPointMake(CGRectGetMidX(bounds), CGRectGetMidY(bounds));
    //_prevLayer.orientation = [[UIDevice currentDevice] orientation];
    [closeButton setFrame:CGRectMake(0, self.view.bounds.size.height - 50, self.view.bounds.size.width, 50)];
    [zoomInButton setFrame:CGRectMake(self.view.bounds.size.width-70, self.view.bounds.size.height - 200, 60, 60)];
    [zoomOutButton setFrame:CGRectMake(self.view.bounds.size.width-70, self.view.bounds.size.height - 130, 60, 60)];
    [flashButton setFrame:CGRectMake(self.view.bounds.size.width-70, self.view.bounds.size.height - 290, 60, 60)];
    
    
    
}

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    [super willRotateToInterfaceOrientation:toInterfaceOrientation duration:duration];
    
    AVCaptureConnection *videoConnection = _prevLayer.connection;
    [videoConnection setVideoOrientation:(AVCaptureVideoOrientation)toInterfaceOrientation];
    
}

// This method will be called once the output is captured. We are using this method to call callback function with the captured value.
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection
{
    
    NSMutableArray *valueOfDic;
    CGRect highlightViewRect = CGRectZero;
    AVMetadataMachineReadableCodeObject *barCodeObject;
    NSString *detectionString = nil;
    NSArray *barCodeTypes = @[AVMetadataObjectTypeUPCECode, AVMetadataObjectTypeCode39Code, AVMetadataObjectTypeCode39Mod43Code,
                              AVMetadataObjectTypeEAN13Code, AVMetadataObjectTypeEAN8Code, AVMetadataObjectTypeCode93Code, AVMetadataObjectTypeCode128Code,
                              AVMetadataObjectTypePDF417Code, AVMetadataObjectTypeQRCode, AVMetadataObjectTypeAztecCode];
    
    for (AVMetadataObject *metadata in metadataObjects) {
        for (NSString *type in barCodeTypes) {
            if ([metadata.type isEqualToString:type])
            {
                barCodeObject = (AVMetadataMachineReadableCodeObject *)[_prevLayer transformedMetadataObjectForMetadataObject:(AVMetadataMachineReadableCodeObject *)metadata];
                highlightViewRect = barCodeObject.bounds;
                detectionString = [(AVMetadataMachineReadableCodeObject *)metadata stringValue];
                break;
            }
        }
        
        if (detectionString != nil)
        {
            
            NSMutableDictionary * infoTable = [NSMutableDictionary dictionary];
            [infoTable setObject:detectionString forKey:@"barcodestring"];
            valueOfDic = [[NSMutableArray alloc] initWithObjects:infoTable, nil];
            [_session removeConnection:connection];
            [_session release];
            [self dismissViewControllerAnimated:YES completion:nil];
            executeClosure(self.barcodeCallback, valueOfDic, false);
            break;
        }
        
    }
    
    _highlightView.frame = highlightViewRect;
}

-(void)viewDidAppear:(BOOL)animated
{
    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if(status == AVAuthorizationStatusDenied) { // authorized
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Impossible de lancer la caméra"
                                                        message:@"Veuillez autoriser l'accès à la caméra ou contacter le support"
                                                       delegate:self
                                              cancelButtonTitle:@"Ok :("
                                              otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
    [UIView animateWithDuration:3.0f animations:^{
        [indicationLabel setAlpha: 1.0f];
        
    } completion:^(BOOL finished){
        [UIView animateWithDuration: 3.0f animations:^{
            [indicationLabel setAlpha:0.0f];
        } completion:nil];
    }];
    
}

-(void)zoomInFunction:(BOOL)zoom
{
    if(_device.videoZoomFactor < 7.0f){
        [_device lockForConfiguration:nil];
        _device.videoZoomFactor = _device.videoZoomFactor + 1.0f;
        [_device unlockForConfiguration];
    }
}

-(void)zoomOutFunction:(BOOL)zoom
{
    if(_device.videoZoomFactor > 1.0f){
        [_device lockForConfiguration:nil];
        _device.videoZoomFactor = _device.videoZoomFactor - 1.0f;
        [_device unlockForConfiguration];
    }
    
}

-(void)flashFunction:(BOOL)flash
{
    if ([_device hasTorch] && [_device hasFlash]){
        
        [_device lockForConfiguration:nil];
        if (_device.torchMode == AVCaptureTorchModeOff)
        {
            [_device setTorchMode:AVCaptureTorchModeOn];
            [_device setFlashMode:AVCaptureFlashModeOn];
            //torchIsOn = YES;
        }
        else
        {
            [_device setTorchMode:AVCaptureTorchModeOff];
            [_device setFlashMode:AVCaptureFlashModeOff];
            // torchIsOn = NO;
        }
        [_device unlockForConfiguration];
    }
    
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    [_session release];
    [_device release];
    [self dismissViewControllerAnimated:YES completion:nil];
    if ([_device hasTorch] && [_device hasFlash]){
        
        [_device lockForConfiguration:nil];
    if (_device.torchMode == AVCaptureTorchModeOn)
    {
        [_device setTorchMode:AVCaptureTorchModeOff];
    }
    }
    NSLog(@"going to background");
}

- (void)applicationDidBecomeActive:(UIApplication *) application {
    [_session release];
    [_device release];
}




@end

