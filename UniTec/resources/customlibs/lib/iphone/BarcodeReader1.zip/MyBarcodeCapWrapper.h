			//
//  MyBarcodeCapWrapper.h
//  VMAppWithKonylib
//
//  Created by Srinivas Vemula on 7/20/15.
//
//

#import <Foundation/Foundation.h>

@interface MyBarcodeCapWrapper:NSObject

+ (void)launchBarcodeCapture:(CallBack *) barcodeCallback;

@end
