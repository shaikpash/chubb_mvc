		//
//  MyBarcodeCapWrapper.m
//  VMAppWithKonylib
//
//  Created by Srinivas Vemula on 7/20/15.
//
//

#import <Foundation/Foundation.h>

#import "MyBarcodeCapture.h"
#import "MyBarcodeCapWrapper.h"
#import "stdlib.h"
#import "lglobals.h"
#import "KonyUIContext.h"

@implementation MyBarcodeCapWrapper

+ (void)launchBarcodeCapture:(CallBack *) barcodeCapCallback;
{
    MyBarcodeCapture* currentview = [[MyBarcodeCapture alloc] initWithNibName:nil bundle:nil];
    currentview.barcodeCallback = barcodeCapCallback;
    
    [KonyUIContext onCurrentFormControllerPresentModalViewController:currentview animated:YES];
}

@end
