#import <Foundation/Foundation.h>

@interface WrapperForiToast : NSObject 

+ (void) showTstMessage: (NSString*) message forDuration: (NSNumber *) duration;

@end



